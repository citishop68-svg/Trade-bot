export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { messages } = req.body;

  const systemPrompt = `Ты — профессиональный трейдинг-ассистент с глубокими знаниями ICT (Inner Circle Trader) и Smart Money Concepts.

Твои компетенции:
- ICT концепции: Order Blocks, Fair Value Gaps (FVG), Breaker Blocks, Mitigation Blocks
- Структура рынка: BOS (Break of Structure), CHoCH (Change of Character), MSS
- Зоны Premium / Discount, равновесие (EQ)
- Ликвидность: BSL/SSL, Equal Highs/Lows, Stop Hunt
- Сессии: Лондон, Нью-Йорк, Азия — их особенности
- Таймфреймы: HTF для bias, LTF для входа
- Управление рисками и позицией (RR, SL/TP)
- Психология трейдинга

Отвечай на русском языке. Будь точным и конкретным. Используй профессиональную терминологию, но объясняй понятно. Если нужно — приводи примеры сценариев входа. Не давай финансовых советов — только образование и анализ концепций.`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          system_instruction: { parts: [{ text: systemPrompt }] },
          contents: messages.map(m => ({
            role: m.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: m.content }]
          })),
          generationConfig: { maxOutputTokens: 1000 }
        })
      }
    );

    const data = await response.json();
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || 'Не удалось получить ответ.';
    res.status(200).json({ reply: text });
  } catch (err) {
    res.status(500).json({ error: 'Ошибка сервера', detail: err.message });
  }
}
